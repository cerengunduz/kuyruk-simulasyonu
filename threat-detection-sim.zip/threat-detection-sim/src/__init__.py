"""Hava Savunma / Tehdit Saptama Kuyruk Simülasyonu paketi."""

__version__ = "1.0.0"
