"""Simülasyon parametrelerini tutan yapı ve YAML/CLI'dan yükleme yardımcıları."""

from __future__ import annotations

import copy
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, Dict

import yaml

DEFAULT_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.yaml"


@dataclass
class SimConfig:
    """Tek bir simülasyon koşusu için tüm parametreler."""

    arrival_rate: float = 0.4
    priority_probs: Dict[str, float] = field(
        default_factory=lambda: {"high": 0.2, "medium": 0.5, "low": 0.3}
    )

    num_radars: int = 2
    detect_mean_time: float = 2.0

    num_classifiers: int = 2
    classify_mean_time: float = 1.5

    num_batteries: int = 1
    engage_mean_time: float = 3.0

    reaction_window: float = 5.0

    sim_time: float = 480.0
    seed: int = 42
    warmup_time: float = 30.0

    def validate(self) -> None:
        total_p = sum(self.priority_probs.values())
        if abs(total_p - 1.0) > 1e-6:
            raise ValueError(
                f"priority_probs toplamı 1.0 olmalı, şu an {total_p:.4f}"
            )
        for name in ("num_radars", "num_classifiers", "num_batteries"):
            if getattr(self, name) < 1:
                raise ValueError(f"{name} en az 1 olmalıdır")
        if self.arrival_rate <= 0:
            raise ValueError("arrival_rate pozitif olmalıdır")

    def copy_with(self, **overrides: Any) -> "SimConfig":
        """Belirli alanları değiştirilmiş yeni bir SimConfig döndürür."""
        data = copy.deepcopy(self.__dict__)
        data.update(overrides)
        return SimConfig(**data)


def load_config(path: str | Path | None = None) -> SimConfig:
    """YAML dosyasından SimConfig yükler; dosya yoksa varsayılanları kullanır."""
    path = Path(path) if path else DEFAULT_CONFIG_PATH
    if not path.exists():
        cfg = SimConfig()
        cfg.validate()
        return cfg

    with open(path, "r", encoding="utf-8") as f:
        raw: Dict[str, Any] = yaml.safe_load(f) or {}

    valid_keys = {f.name for f in fields(SimConfig)}
    filtered = {k: v for k, v in raw.items() if k in valid_keys}
    cfg = SimConfig(**filtered)
    cfg.validate()
    return cfg
