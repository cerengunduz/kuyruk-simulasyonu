"""Simülasyon varlıkları: Threat (tehdit) ve istatistik toplama yapıları."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


# SimPy PriorityResource'ta küçük sayı = yüksek öncelik
PRIORITY_LEVELS = {"high": 0, "medium": 1, "low": 2}


@dataclass
class Threat:
    """Sistemdeki tek bir tehdidi (uçak/füze/İHA vb.) temsil eder."""

    threat_id: int
    priority: str  # "high" | "medium" | "low"
    arrival_time: float

    detect_start: Optional[float] = None
    detect_end: Optional[float] = None
    classify_start: Optional[float] = None
    classify_end: Optional[float] = None
    engage_start: Optional[float] = None
    engage_end: Optional[float] = None

    reneged: bool = False  # Tespit kuyruğunda çok bekleyip kayıp olduysa True

    @property
    def priority_level(self) -> int:
        return PRIORITY_LEVELS[self.priority]

    @property
    def detect_wait(self) -> Optional[float]:
        if self.detect_start is None:
            return None
        return self.detect_start - self.arrival_time

    @property
    def classify_wait(self) -> Optional[float]:
        if self.classify_start is None or self.detect_end is None:
            return None
        return self.classify_start - self.detect_end

    @property
    def engage_wait(self) -> Optional[float]:
        if self.engage_start is None or self.classify_end is None:
            return None
        return self.engage_start - self.classify_end

    @property
    def sojourn_time(self) -> Optional[float]:
        if self.engage_end is None:
            return None
        return self.engage_end - self.arrival_time


@dataclass
class StatsCollector:
    """Bir simülasyon koşusu boyunca tüm tehditlerin kaydını ve zaman serilerini tutar."""

    warmup_time: float = 0.0
    threats: List[Threat] = field(default_factory=list)

    # Zaman serisi örnekleri: (zaman, kuyruk_uzunlugu)
    radar_queue_series: List[tuple] = field(default_factory=list)
    classify_queue_series: List[tuple] = field(default_factory=list)
    engage_queue_series: List[tuple] = field(default_factory=list)

    # Kaynak meşguliyet zamanı biriktirme (utilization hesaplamak için)
    radar_busy_time: float = 0.0
    classify_busy_time: float = 0.0
    engage_busy_time: float = 0.0

    def record_threat(self, threat: Threat) -> None:
        self.threats.append(threat)

    def record_queue_length(self, series_name: str, time: float, length: int) -> None:
        getattr(self, series_name).append((time, length))

    def _completed_after_warmup(self) -> List[Threat]:
        return [
            t
            for t in self.threats
            if t.arrival_time >= self.warmup_time and t.engage_end is not None
        ]

    def _reneged_after_warmup(self) -> List[Threat]:
        return [
            t
            for t in self.threats
            if t.arrival_time >= self.warmup_time and t.reneged
        ]
