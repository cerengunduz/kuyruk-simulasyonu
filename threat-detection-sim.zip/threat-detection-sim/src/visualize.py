"""
run_experiment.py tarafından üretilen CSV sonuçlarını grafikle gösterir.

Kullanım:
    python -m src.visualize results/run.csv
    python -m src.visualize results/sweep_radars.csv --sweep-param num_radars
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List, Optional

import matplotlib

matplotlib.use("Agg")  # Sunucu / headless ortamlarda da calissin
import matplotlib.pyplot as plt
import pandas as pd

_STANDARD_COLUMNS = {
    "replication",
    "seed",
    "total_arrivals",
    "completed",
    "reneged",
    "reneged_rate",
    "avg_detect_wait",
    "p95_detect_wait",
    "avg_classify_wait",
    "avg_engage_wait",
    "avg_sojourn_time",
    "p95_sojourn_time",
    "radar_utilization",
    "classifier_utilization",
    "battery_utilization",
}


def _detect_sweep_param(df: pd.DataFrame) -> Optional[str]:
    extra = [c for c in df.columns if c not in _STANDARD_COLUMNS]
    return extra[0] if extra else None


def plot_sweep(df: pd.DataFrame, sweep_param: str, out_dir: Path) -> List[Path]:
    grouped = df.groupby(sweep_param).mean(numeric_only=True).reset_index()
    outputs = []

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(grouped[sweep_param], grouped["reneged_rate"], marker="o", color="#c0392b")
    ax.set_xlabel(sweep_param)
    ax.set_ylabel("Ortalama kayip (undetected) orani")
    ax.set_title(f"Kayip Tehdit Orani vs {sweep_param}")
    ax.grid(alpha=0.3)
    path = out_dir / f"reneged_rate_vs_{sweep_param}.png"
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    outputs.append(path)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(
        grouped[sweep_param], grouped["avg_sojourn_time"], marker="o", color="#2980b9"
    )
    ax.set_xlabel(sweep_param)
    ax.set_ylabel("Ortalama sistemde kalis suresi (dk)")
    ax.set_title(f"Sistemde Kalis Suresi vs {sweep_param}")
    ax.grid(alpha=0.3)
    path = out_dir / f"sojourn_time_vs_{sweep_param}.png"
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    outputs.append(path)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    for col, label in [
        ("radar_utilization", "Radar"),
        ("classifier_utilization", "Siniflandirma"),
        ("battery_utilization", "Batarya"),
    ]:
        ax.plot(grouped[sweep_param], grouped[col], marker="o", label=label)
    ax.set_xlabel(sweep_param)
    ax.set_ylabel("Kaynak kullanim orani")
    ax.set_title(f"Kaynak Kullanimi vs {sweep_param}")
    ax.legend()
    ax.grid(alpha=0.3)
    path = out_dir / f"utilization_vs_{sweep_param}.png"
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    outputs.append(path)

    return outputs


def plot_single_run(df: pd.DataFrame, out_dir: Path) -> List[Path]:
    means = df.mean(numeric_only=True)
    outputs = []

    fig, ax = plt.subplots(figsize=(6, 4))
    stages = ["avg_detect_wait", "avg_classify_wait", "avg_engage_wait"]
    labels = ["Radar/Tespit", "Siniflandirma", "Angajman"]
    ax.bar(labels, [means[s] for s in stages], color=["#e67e22", "#2980b9", "#8e44ad"])
    ax.set_ylabel("Ortalama bekleme suresi (dk)")
    ax.set_title("Asama Basina Ortalama Bekleme Suresi")
    path = out_dir / "avg_wait_by_stage.png"
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    outputs.append(path)

    fig, ax = plt.subplots(figsize=(6, 4))
    util_cols = ["radar_utilization", "classifier_utilization", "battery_utilization"]
    ax.bar(labels, [means[c] for c in util_cols], color=["#16a085", "#2980b9", "#c0392b"])
    ax.set_ylabel("Kullanim orani (0-1)")
    ax.set_ylim(0, 1)
    ax.set_title("Kaynak Kullanim Oranlari")
    path = out_dir / "resource_utilization.png"
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    outputs.append(path)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(
        ["Kayip Orani"],
        [means["reneged_rate"]],
        color="#c0392b",
    )
    ax.set_ylim(0, 1)
    ax.set_title("Ortalama Kayip (Undetected) Tehdit Orani")
    path = out_dir / "reneged_rate.png"
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    outputs.append(path)

    return outputs


def main(argv: List[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Simulasyon sonuclarini gorsellestir")
    parser.add_argument("csv_path", type=str, help="run_experiment.py CSV ciktisi")
    parser.add_argument(
        "--sweep-param",
        type=str,
        default=None,
        help="Sweep parametresi adi (otomatik algilanmaya calisilir)",
    )
    parser.add_argument("--out-dir", type=str, default=None)
    args = parser.parse_args(argv)

    csv_path = Path(args.csv_path)
    df = pd.read_csv(csv_path)
    out_dir = Path(args.out_dir) if args.out_dir else csv_path.parent
    out_dir.mkdir(parents=True, exist_ok=True)

    sweep_param = args.sweep_param or _detect_sweep_param(df)

    if sweep_param:
        outputs = plot_sweep(df, sweep_param, out_dir)
    else:
        outputs = plot_single_run(df, out_dir)

    print("Grafikler kaydedildi:")
    for p in outputs:
        print(f"  - {p}")


if __name__ == "__main__":
    main(sys.argv[1:])
