"""
Hava Savunma / Tehdit Saptama Kuyruk Simülasyonu - Çekirdek Model
==================================================================

Üç aşamalı bir tandem (seri) kuyruk ağı:

    Varış --> [Radar/Tespit] --> [Sınıflandırma] --> [Angajman/İmha] --> Çıkış

- Varışlar: Poisson süreci (üstel geliş aralıkları)
- Her aşama: simpy.PriorityResource (yüksek öncelikli tehditler önce işlenir)
- Servis süreleri: üstel dağılım (ortalama parametre ile)
- Tespit kuyruğunda "reaction_window" süresinden fazla bekleyen tehdit kayıp sayılır
  (renege / balking davranışı)

Bu dosya yalnızca bir simülasyon *motorudur*; deneyleri çalıştırmak için
`run_experiment.py`'yi, görselleştirmek için `visualize.py`'yi kullanın.
"""

from __future__ import annotations

import random
from typing import Generator

import simpy

from .config import SimConfig
from .entities import PRIORITY_LEVELS, StatsCollector, Threat


def _sample_priority(rng: random.Random, probs: dict) -> str:
    levels = list(probs.keys())
    weights = list(probs.values())
    return rng.choices(levels, weights=weights, k=1)[0]


def threat_generator(
    env: simpy.Environment,
    cfg: SimConfig,
    rng: random.Random,
    radar: simpy.PriorityResource,
    classifier: simpy.PriorityResource,
    battery: simpy.PriorityResource,
    stats: StatsCollector,
) -> Generator:
    """Poisson sürecine göre yeni tehdit varışları üretir."""
    threat_id = 0
    while True:
        interarrival = rng.expovariate(cfg.arrival_rate)
        yield env.timeout(interarrival)

        threat_id += 1
        priority = _sample_priority(rng, cfg.priority_probs)
        threat = Threat(
            threat_id=threat_id,
            priority=priority,
            arrival_time=env.now,
        )
        stats.record_threat(threat)
        env.process(
            threat_pipeline(env, cfg, rng, threat, radar, classifier, battery, stats)
        )


def threat_pipeline(
    env: simpy.Environment,
    cfg: SimConfig,
    rng: random.Random,
    threat: Threat,
    radar: simpy.PriorityResource,
    classifier: simpy.PriorityResource,
    battery: simpy.PriorityResource,
    stats: StatsCollector,
) -> Generator:
    """Tek bir tehdidin üç aşamadan geçiş sürecini yönetir."""

    priority_level = threat.priority_level

    # ---- Aşama 1: Radar / Tespit (sabırsızlık / reneging ile) ----
    with radar.request(priority=priority_level) as req:
        result = yield req | env.timeout(cfg.reaction_window)
        if req not in result:
            # Reaksiyon penceresi doldu, tehdit tespit edilemeden kayboldu
            threat.reneged = True
            return

        threat.detect_start = env.now
        stats.record_queue_length("radar_queue_series", env.now, len(radar.queue))
        service = rng.expovariate(1.0 / cfg.detect_mean_time)
        yield env.timeout(service)
        threat.detect_end = env.now
        stats.radar_busy_time += service

    # ---- Aşama 2: Sınıflandırma ----
    with classifier.request(priority=priority_level) as req:
        yield req
        threat.classify_start = env.now
        stats.record_queue_length(
            "classify_queue_series", env.now, len(classifier.queue)
        )
        service = rng.expovariate(1.0 / cfg.classify_mean_time)
        yield env.timeout(service)
        threat.classify_end = env.now
        stats.classify_busy_time += service

    # ---- Aşama 3: Angajman / İmha ----
    with battery.request(priority=priority_level) as req:
        yield req
        threat.engage_start = env.now
        stats.record_queue_length("engage_queue_series", env.now, len(battery.queue))
        service = rng.expovariate(1.0 / cfg.engage_mean_time)
        yield env.timeout(service)
        threat.engage_end = env.now
        stats.engage_busy_time += service


def run_simulation(cfg: SimConfig, seed: int | None = None) -> StatsCollector:
    """Tek bir simülasyon koşusu çalıştırır ve StatsCollector döndürür."""
    cfg.validate()
    rng = random.Random(seed if seed is not None else cfg.seed)

    env = simpy.Environment()
    radar = simpy.PriorityResource(env, capacity=cfg.num_radars)
    classifier = simpy.PriorityResource(env, capacity=cfg.num_classifiers)
    battery = simpy.PriorityResource(env, capacity=cfg.num_batteries)

    stats = StatsCollector(warmup_time=cfg.warmup_time)

    env.process(
        threat_generator(env, cfg, rng, radar, classifier, battery, stats)
    )
    env.run(until=cfg.sim_time)

    return stats
