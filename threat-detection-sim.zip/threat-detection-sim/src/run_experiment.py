"""
Komut satırından simülasyonu çalıştırma aracı.

Kullanım örnekleri
------------------
Tek koşu:
    python -m src.run_experiment --sim-time 480 --arrival-rate 0.5

Parametre taraması + tekrar (replication):
    python -m src.run_experiment --sweep num_radars=1,2,3,4 --replications 10 \
        --output results/sweep_radars.csv
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path
from typing import Any, Dict, List

from .config import SimConfig, load_config
from .metrics import compute_summary
from .simulation import run_simulation


def _parse_sweep(sweep_arg: str) -> Dict[str, List[Any]]:
    """'num_radars=1,2,3' -> {'num_radars': [1, 2, 3]} (sayısal olarak parse edilir)."""
    if "=" not in sweep_arg:
        raise ValueError("--sweep formatı: parametre_adi=deger1,deger2,...")
    key, raw_values = sweep_arg.split("=", 1)
    values: List[Any] = []
    for v in raw_values.split(","):
        v = v.strip()
        try:
            values.append(int(v))
        except ValueError:
            try:
                values.append(float(v))
            except ValueError:
                values.append(v)
    return {key.strip(): values}


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Tehdit Saptama Kuyruk Simülasyonu")
    p.add_argument("--config", type=str, default=None, help="config.yaml yolu")
    p.add_argument("--sim-time", type=float, default=None)
    p.add_argument("--arrival-rate", type=float, default=None)
    p.add_argument("--num-radars", type=int, default=None)
    p.add_argument("--num-classifiers", type=int, default=None)
    p.add_argument("--num-batteries", type=int, default=None)
    p.add_argument("--reaction-window", type=float, default=None)
    p.add_argument("--seed", type=int, default=None)
    p.add_argument(
        "--sweep",
        type=str,
        default=None,
        help="ornek: num_radars=1,2,3,4 - bir parametreyi tarar",
    )
    p.add_argument(
        "--replications",
        type=int,
        default=1,
        help="Her parametre kombinasyonu icin tekrar sayisi",
    )
    p.add_argument(
        "--output",
        type=str,
        default="results/run.csv",
        help="Sonuclarin yazilacagi CSV dosyasi",
    )
    return p


def apply_cli_overrides(cfg: SimConfig, args: argparse.Namespace) -> SimConfig:
    overrides = {}
    for field_name in (
        "sim_time",
        "arrival_rate",
        "num_radars",
        "num_classifiers",
        "num_batteries",
        "reaction_window",
        "seed",
    ):
        cli_val = getattr(args, field_name.replace("_", "_"))
        if cli_val is not None:
            overrides[field_name] = cli_val
    return cfg.copy_with(**overrides) if overrides else cfg


def run_single(cfg: SimConfig, replications: int) -> List[Dict[str, Any]]:
    rows = []
    for rep in range(replications):
        seed = cfg.seed + rep
        stats = run_simulation(cfg, seed=seed)
        summary = compute_summary(stats, cfg)
        row = {"replication": rep, "seed": seed, **summary.to_dict()}
        rows.append(row)
    return rows


def main(argv: List[str] | None = None) -> None:
    args = build_arg_parser().parse_args(argv)
    base_cfg = load_config(args.config)
    base_cfg = apply_cli_overrides(base_cfg, args)

    all_rows: List[Dict[str, Any]] = []

    if args.sweep:
        sweep_dict = _parse_sweep(args.sweep)
        (param_name, values), = sweep_dict.items()
        for value in values:
            cfg = base_cfg.copy_with(**{param_name: value})
            rows = run_single(cfg, args.replications)
            for row in rows:
                row[param_name] = value
                all_rows.append(row)
            avg_reneged = sum(r["reneged_rate"] for r in rows) / len(rows)
            print(
                f"[{param_name}={value}] ort. kayip orani={avg_reneged:.3f} "
                f"({args.replications} tekrar)"
            )
    else:
        rows = run_single(base_cfg, args.replications)
        all_rows.extend(rows)
        avg = rows[0] if len(rows) == 1 else None
        for row in rows:
            print(
                f"[rep={row['replication']}] "
                f"varis={row['total_arrivals']} "
                f"tamamlanan={row['completed']} "
                f"kayip_orani={row['reneged_rate']:.3f} "
                f"ort_tespit_bekleme={row['avg_detect_wait']:.2f}dk "
                f"ort_sistemde_kalis={row['avg_sojourn_time']:.2f}dk "
                f"radar_kullanim={row['radar_utilization']:.2f}"
            )

    if all_rows:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(all_rows[0].keys()))
            writer.writeheader()
            writer.writerows(all_rows)
        print(f"\nSonuclar yazildi -> {out_path}")


if __name__ == "__main__":
    main(sys.argv[1:])
