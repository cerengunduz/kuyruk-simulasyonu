"""StatsCollector çıktısından özet performans metrikleri hesaplar."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Dict, List

import numpy as np

from .config import SimConfig
from .entities import StatsCollector, Threat


@dataclass
class SummaryMetrics:
    total_arrivals: int
    completed: int
    reneged: int
    reneged_rate: float

    avg_detect_wait: float
    p95_detect_wait: float
    avg_classify_wait: float
    avg_engage_wait: float
    avg_sojourn_time: float
    p95_sojourn_time: float

    radar_utilization: float
    classifier_utilization: float
    battery_utilization: float

    def to_dict(self) -> Dict:
        return asdict(self)


def _safe_mean(values: List[float]) -> float:
    return float(np.mean(values)) if values else 0.0


def _safe_p95(values: List[float]) -> float:
    return float(np.percentile(values, 95)) if values else 0.0


def compute_summary(stats: StatsCollector, cfg: SimConfig) -> SummaryMetrics:
    warm = stats.warmup_time
    horizon = cfg.sim_time - warm

    arrivals_after_warmup: List[Threat] = [
        t for t in stats.threats if t.arrival_time >= warm
    ]
    completed = [t for t in arrivals_after_warmup if t.engage_end is not None]
    reneged = [t for t in arrivals_after_warmup if t.reneged]

    detect_waits = [t.detect_wait for t in completed if t.detect_wait is not None]
    classify_waits = [
        t.classify_wait for t in completed if t.classify_wait is not None
    ]
    engage_waits = [t.engage_wait for t in completed if t.engage_wait is not None]
    sojourns = [t.sojourn_time for t in completed if t.sojourn_time is not None]

    total = len(arrivals_after_warmup)
    reneged_rate = (len(reneged) / total) if total else 0.0

    radar_util = (
        stats.radar_busy_time / (cfg.num_radars * horizon) if horizon > 0 else 0.0
    )
    classify_util = (
        stats.classify_busy_time / (cfg.num_classifiers * horizon)
        if horizon > 0
        else 0.0
    )
    engage_util = (
        stats.engage_busy_time / (cfg.num_batteries * horizon) if horizon > 0 else 0.0
    )

    return SummaryMetrics(
        total_arrivals=total,
        completed=len(completed),
        reneged=len(reneged),
        reneged_rate=reneged_rate,
        avg_detect_wait=_safe_mean(detect_waits),
        p95_detect_wait=_safe_p95(detect_waits),
        avg_classify_wait=_safe_mean(classify_waits),
        avg_engage_wait=_safe_mean(engage_waits),
        avg_sojourn_time=_safe_mean(sojourns),
        p95_sojourn_time=_safe_p95(sojourns),
        radar_utilization=min(radar_util, 1.0),
        classifier_utilization=min(classify_util, 1.0),
        battery_utilization=min(engage_util, 1.0),
    )
