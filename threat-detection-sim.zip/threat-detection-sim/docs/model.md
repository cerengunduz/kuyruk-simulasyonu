# Matematiksel Model ve Varsayımlar

## 1. Genel Bakış

Sistem, üç istasyonlu bir **tandem kuyruk ağı** olarak modellenmiştir:

```
Varış (λ) → [M/M/c₁ + renege] → [M/M/c₂] → [M/M/c₃] → Çıkış
```

- İstasyon 1 (Radar/Tespit): `c₁ = num_radars` sunucu, servis oranı `μ₁ = 1/detect_mean_time`
- İstasyon 2 (Sınıflandırma): `c₂ = num_classifiers` sunucu, servis oranı `μ₂ = 1/classify_mean_time`
- İstasyon 3 (Angajman): `c₃ = num_batteries` sunucu, servis oranı `μ₃ = 1/engage_mean_time`

## 2. Varış Süreci

Tehditlerin varışı **homojen Poisson süreci** olarak modellenir: ardışık varışlar
arası süre `Exponential(λ)` dağılımına sahiptir (`λ = arrival_rate`, dakikada
ortalama tehdit sayısı). Her varışa bağımsız olarak bir öncelik seviyesi
(`high`/`medium`/`low`) `priority_probs` dağılımından örneklenir.

## 3. Servis Süreçleri

Basitlik ve analitik izlenebilirlik için her aşamadaki servis süresi üstel
dağılımdan örneklenir (klasik M/M/c varsayımı). Bu, gerçek sistemlerde genellikle
daha az değişkenlik gösteren (ör. sabit veya Erlang dağılımlı) servis sürelerine
göre **daha kötümser (worst-case'e yakın)** bir yaklaşımdır; istenirse
`rng.expovariate` çağrıları `rng.triangular` veya `rng.gammavariate` ile
kolayca değiştirilebilir.

## 4. Öncelik Mekanizması

Her istasyon bir `simpy.PriorityResource` olarak modellenmiştir. Bir tehdit
kuyrukta beklerken, kendisinden daha yüksek öncelikli (küçük sayı = yüksek
öncelik: high=0, medium=1, low=2) bir tehdit gelirse, o tehdit kuyrukta öne
geçer. Bu, gerçek hava savunma karar süreçlerindeki "önce en tehlikeli hedef"
mantığını basitçe yaklaşıklar. **Önemli**: Model *preemptive* değildir — hâlihazırda
servis alan bir tehdit, daha yüksek öncelikli biri geldiğinde yarıda kesilmez;
yalnızca kuyruktaki sıralama değişir.

## 5. Sabırsızlık / Kayıp Tehditler (Reneging)

Gerçek dünyada bir tehdidin tespit edilip müdahale edilebileceği süre sınırlıdır
(“reaksiyon penceresi”, `reaction_window`). Bu, ilk aşamada
`req | env.timeout(reaction_window)` ile modellenir: tehdit bu süre içinde bir
radar kaynağına erişemezse, `reneged = True` olarak işaretlenir ve sistemden
"tespit edilemeden" çıkar. Bu, sistem performansının en kritik göstergelerinden
biridir (bkz. `reneged_rate` metriği).

## 6. Isınma Süresi (Warm-up)

Simülasyonun başında sistem henüz "kararlı duruma" (steady state) ulaşmamıştır
(kuyruklar boş başlar). Bu geçiş etkisini istatistiklerden arındırmak için
`warmup_time` dakikadan önce **varan** tehditler özet istatistiklere dahil
edilmez (`compute_summary` bunu otomatik uygular). Bu, standart kuyruk
simülasyonu pratiğidir (bkz. Law & Kelton, *Simulation Modeling and Analysis*).

## 7. Kullanılabilirlik (Utilization) Hesabı

Her kaynak için kullanım oranı:

```
utilization = toplam_meşgul_süre / (sunucu_sayısı × (sim_time - warmup_time))
```

`toplam_meşgul_süre`, o aşamada gerçekleşen tüm servis sürelerinin toplamıdır
(ısınma sonrası varışlar için biriktirilir).

## 8. Sınırlamalar ve Genişletme Fikirleri

- Servis süreleri şu an sabit dağılım ailesinden (üstel); farklı hedef tipleri
  için farklı servis süresi dağılımları eklenebilir.
- Model *tek katmanlı* bir savunma hattını temsil eder; çok katmanlı (ör. uzun
  menzil + kısa menzil savunma) senaryolar için ek istasyonlar eklenebilir.
- Angajman aşamasında "başarısız imha" (bir bataryanın hedefi ilk seferde
  etkisiz hale getirememesi ve tekrar denemesi) şu an modellenmemiştir; bu,
  `threat_pipeline` içine bir olasılıksal döngü eklenerek genişletilebilir.
- Bu proje eğitim/akademik amaçlıdır; operasyonel karar destek sistemi olarak
  kullanılmak üzere tasarlanmamıştır.

## 9. Kaynaklar

- Law, A. M., & Kelton, W. D. *Simulation Modeling and Analysis*.
- SimPy Resmi Dokümantasyonu: https://simpy.readthedocs.io/
- Gross, D., & Harris, C. M. *Fundamentals of Queueing Theory*.
