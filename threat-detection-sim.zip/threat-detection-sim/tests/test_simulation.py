"""Simülasyon modelinin temel sağlamlık (sanity) testleri."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.config import SimConfig
from src.metrics import compute_summary
from src.simulation import run_simulation


def make_test_config(**overrides) -> SimConfig:
    base = dict(
        arrival_rate=0.5,
        num_radars=2,
        detect_mean_time=1.0,
        num_classifiers=2,
        classify_mean_time=1.0,
        num_batteries=2,
        engage_mean_time=1.0,
        reaction_window=10.0,
        sim_time=200.0,
        seed=1,
        warmup_time=10.0,
    )
    base.update(overrides)
    return SimConfig(**base)


def test_simulation_runs_and_produces_arrivals():
    cfg = make_test_config()
    stats = run_simulation(cfg, seed=cfg.seed)
    assert len(stats.threats) > 0, "Simulasyon hic tehdit uretmedi"


def test_completed_threats_have_consistent_timestamps():
    cfg = make_test_config()
    stats = run_simulation(cfg, seed=cfg.seed)
    completed = [t for t in stats.threats if t.engage_end is not None]
    assert completed, "Hic tamamlanan tehdit yok"
    for t in completed:
        assert t.arrival_time <= t.detect_start <= t.detect_end
        assert t.detect_end <= t.classify_start <= t.classify_end
        assert t.classify_end <= t.engage_start <= t.engage_end
        assert t.sojourn_time >= 0


def test_reproducibility_with_same_seed():
    cfg = make_test_config()
    stats1 = run_simulation(cfg, seed=123)
    stats2 = run_simulation(cfg, seed=123)
    assert len(stats1.threats) == len(stats2.threats)
    for t1, t2 in zip(stats1.threats, stats2.threats):
        assert t1.arrival_time == t2.arrival_time
        assert t1.priority == t2.priority


def test_summary_metrics_are_in_valid_ranges():
    cfg = make_test_config()
    stats = run_simulation(cfg, seed=cfg.seed)
    summary = compute_summary(stats, cfg)

    assert 0.0 <= summary.reneged_rate <= 1.0
    assert 0.0 <= summary.radar_utilization <= 1.0
    assert 0.0 <= summary.classifier_utilization <= 1.0
    assert 0.0 <= summary.battery_utilization <= 1.0
    assert summary.avg_sojourn_time >= 0.0


def test_understaffed_system_has_higher_reneging():
    """Az kaynakla (1 radar) kayip orani, bol kaynakli sisteme gore daha yuksek olmali."""
    cfg_scarce = make_test_config(num_radars=1, arrival_rate=1.2, reaction_window=3.0)
    cfg_ample = make_test_config(num_radars=6, arrival_rate=1.2, reaction_window=3.0)

    stats_scarce = run_simulation(cfg_scarce, seed=7)
    stats_ample = run_simulation(cfg_ample, seed=7)

    summary_scarce = compute_summary(stats_scarce, cfg_scarce)
    summary_ample = compute_summary(stats_ample, cfg_ample)

    assert summary_scarce.reneged_rate >= summary_ample.reneged_rate


def test_config_validation_rejects_bad_priority_probs():
    import pytest

    cfg = SimConfig(priority_probs={"high": 0.5, "medium": 0.6, "low": 0.1})
    with pytest.raises(ValueError):
        cfg.validate()
